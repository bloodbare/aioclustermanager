from __future__ import absolute_import

__author__ = 'Ramon Navarro'
__email__ = 'ramon@onna.com'
__version__ = '0.1.0'

__all__ = (
    'manager',
    'job',
    'job_list'
)
